def positive_amount(prompt):
    while True:
        try:
            value = float(input(prompt))
            if value <= 0:
                print("Amount must be greater than zero.")
                continue
            return value
        except ValueError:
            print("Invalid input. Enter a number.")

def main():
    print("PERSONAL FINANCE EXPENSE ANALYZER")
    budget = positive_amount("Enter monthly budget (Rs): ")
    expenses = []
    while True:
        print("\\nMENU: 1.Add  2.View  3.Analyze  4.Sort  5.Exit")
        choice = input("Choose option: ").strip()
        if choice == "1":
            category = input("Category: ").strip().title()
            amount = positive_amount("Amount (Rs): ")
            note = input("Note: ").strip() or "No note"
            expenses.append({"category": category, "amount": amount, "note": note})
            print("Expense added successfully.")
        elif choice == "2":
            if not expenses:
                print("No expenses recorded.")
            else:
                print("\\nNo.  Category          Amount (Rs)   Note")
                for i,e in enumerate(expenses,1):
                    print(f"{i:<4} {e['category']:<17} {e['amount']:>10.2f}   {e['note']}")
        elif choice == "3":
            if not expenses:
                print("Add expenses before analysis.")
                continue
            total=sum(e["amount"] for e in expenses)
            by_cat={}
            for e in expenses:
                by_cat[e["category"]]=by_cat.get(e["category"],0)+e["amount"]
            print("\\n========== EXPENSE ANALYSIS ==========")
            print(f"Monthly budget : Rs {budget:.2f}")
            print(f"Total spending : Rs {total:.2f}")
            print(f"Remaining      : Rs {budget-total:.2f}")
            print("Category-wise spending:")
            for cat,amt in sorted(by_cat.items(),key=lambda x:x[1],reverse=True):
                print(f"- {cat:<12} Rs {amt:>8.2f} ({amt/total*100:.1f}%)")
            print("Highest spending category:",max(by_cat,key=by_cat.get))
            usage=total/budget*100
            print(f"Budget used: {usage:.1f}%")
            if total>budget: print("Status: OVER BUDGET")
            elif total==budget: print("Status: BUDGET FULLY USED")
            elif usage>=80: print("Status: WARNING - 80% or more used")
            else: print("Status: WITHIN BUDGET")
        elif choice == "4":
            for i,e in enumerate(sorted(expenses,key=lambda x:x["amount"],reverse=True),1):
                print(f"{i}. {e['category']}: Rs {e['amount']:.2f} - {e['note']}")
        elif choice == "5":
            print("Thank you for using the analyzer.")
            break
        else:
            print("Invalid menu choice.")

if __name__ == "__main__":
    main()
